# ft_ls
ft_ls 42
